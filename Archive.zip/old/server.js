// //Create server via HTTP // in command write -> node server -> enter on www:localhost:3000 ------------------ --------------------------------------
// // let http = require("http");

// // let ourApp = http.createServer(function(req, res) {
// //     // console.log(req.url); //show what the url you enter e.g. /about and showed in terminal
// //     if ( req.url == "/" ) {
// //         res.end('hee lo it is server'); // display text in site
// //     } else if ( req.url == "/about" ) {
// //         res.end('it is about');
// //     } else {
// //         res.end('it is empty, sorry');
// //     }

// // });
// // ourApp.listen(3000);

// //Create server via express // in command write -> node server -> enter on www:localhost:3000 ------------------ --------------------------------------
// let express = require("express");
// let ourApp = express();

// ourApp.use(express.urlencoded({ extended: false })) // turn off that why skyColor - will works

// ourApp.get('/', function(req, res) {
//     res.send(`
// <h2>what is color of sky?</h2>

// <form action="/answer" method="POST" class="form_color">
//     <input name="skyColor" type="text">
//     <button>submit answer</button>
// </form>
//     `);
// } );

// ourApp.post('/answer', function(req, res) {
    
//     if ( req.body.skyColor == 'blue' ) { // skyColo.toUpperCase() find olny uppercase text
//         res.send(`
//         <h2>Corrent</h2>
//         <a href="/">Back</a>
//         `);

//     } else {
//         res.send(`<h2>Don't Corrent</h2>`);
//     }
//     // res.send(`<a href="/">Back</a>`); // not works double res.send..

// } );

// ourApp.get('/answer', function(req, res) {
//     res.send(`<h2>Are you lost?</h2>`);
// } );

// ourApp.listen(3000);
