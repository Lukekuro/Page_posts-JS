<link rel="stylesheet" href="style.css">
<h1>Study JS</h1>

<h2>to-do-app</h2>

<form class="create_item">
    <input type="text" name="create_item">
    <button>Create item</button>
    <span class="is_empty d-none">is empty</span>
</form>

<h3>Need to do</h3>
<ul class="list">
<li> is<button class="delete">delete</button></li>
</ul>






<script src="custom.js"></script>