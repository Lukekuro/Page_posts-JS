//function --------------------------------------
function greet(theName, favColor) {
    document.write("Hello, my name is " + theName + " and my fav color is " + favColor + ".");
}

// greet("eminem", "red");

//Object --------------------------------------
let cat = {
    name: "kitty",
    age: 4,
    food: {
        fav: "tuna",
        fruit: "orange"
    },
    displaytext() {
        function display() {
            document.write(this);
        }
        //Or Or OR + Anomyous function --------
        let display_text = () => console.log(this);
        display_text();

        // display();
        document.write("My name cat is " + this.name + " and her fav food is " + this.food.fav);
    }
}
// cat.name = "bat";

// document.write(cat.food.fav); // tuna

// cat.displaytext(); // display from funtion

//Array --------------------------------------
let num = [9,2,4];
let myPets = [{name: "meow", species: "cat"},{name:"pudel", species: "dog"}];

let newpet = {name: "batman", species: "dog"};
let color = ["yel", "red"];
num.push(10);
// num.splice(0,2); //remove from index and how much

// document.write(num); // display numbers

// // document.write(myPets[0].name); // display name -> meow

myPets.push(newpet); // or myPets.push({name: "batman", species: "bat"});
// console.log(myPets);


// Get from array and create forEach --------------------------------------
// color.forEach(saysomething); // display text from function saysomething

function saysomething(key) {
    // document.write("COlor is : " + key + "</br>");
    //OR OR or or
    document.write(`COlor is : ${key} </br>`);
}

//MAP Pets --------------------------------------
let map_pets = myPets.map(nameOnly); 

function nameOnly(x) { // x pobiera wartosc z array. Nawet nie trzeba (x) u górze 
    return x.name; // x.name wyswietla tylko name - DISPLAY ONLY NAME
}

//FILTER Pets as dog --------------------------------------
let filter_pets = myPets.filter(OnlyDogs); //filter

function OnlyDogs(x) {
    return x.species == "dog"; // find only dog
}

//Map + Filter --------------------------------------
let wynikPets = myPets.filter(OnlyDogs).map(nameOnly);


// console.log(wynikPets);

//Higher-order function --------------------------------------
function createmulti(multi) {  //create multiplication - need is here double number
    return function(x) { 
        return x * multi;
    }
}

let double = createmulti(2); // double * 2

// document.write(double(10)); // display 20

//Create function from OBJECT as Cat via method as .call --------------------------------------

function breathe() {
    document.write(this.name + " " + this.age);
}

// breathe.call(cat); // display from function

//Anomyous function  --------------------------------------
// document.addEventListener("click", function() {
//     console.log("thanks");
// } );
// //OR OR 
// document.addEventListener("click", () => console.log("no thanks"));

//Map function + Anomyous function --------------------------------------
let numbers = [5, 10];
let doublenumbers = numbers.map(function(x) {
    return x * 2
} );
// //OR OR 
let doublenumbers2 = numbers.map(x => x * 3 );


// document.write(doublenumbers2); // display from doublenumbers

//function hoisting - hoising is e.g. you can call from function (never mind if you are above or below from funcion) --------------------------------------


//TO DO APP  -------------------------------------- --------------------------------------
function focus_on_input(x) {
    x.addEventListener('focus', () => {
        ourForm_is_empty.classList.add("d-none");
    })
}

function createItem(x) {
    let ourHTML = `<li> ${x} <button class="delete">delete</button></li>`;
    list.insertAdjacentHTML( "beforeend", ourHTML );
    ourForm_input.value = '';
    ourForm_input.focus();
    console.log('creatr');
}

function deleteItem() {
    list_del = list.querySelectorAll(".delete");

    list_del.forEach((item) => {
        item.addEventListener("click", () => {
            item.parentElement.remove();
        } );
    });
}

let ourForm = document.querySelector(".create_item"),
ourForm_input = ourForm.querySelector("input"),
ourForm_is_empty = ourForm.querySelector(".is_empty"),
ourForm_btn = ourForm.querySelector("button"),
list = document.querySelector(".list");


ourForm.addEventListener( "submit", (e) => {
    e.preventDefault();
    if ( ourForm_input.value === '' ) {
        ourForm_is_empty.classList.remove("d-none");
    } else {
        createItem(ourForm_input.value);
        deleteItem();
    }
});



focus_on_input(ourForm_input);

deleteItem();


// Form Color  -------------------------------------- --------------------------------------

let form_color = document.querySelector('.form_color'),
form_color_input = form_color.querySelector('input'),
form_color_button = form_color.querySelector('button');

form_color.addEventListener("submit", (e) => {
    e.preventDefault();
    if ( form_color_input.value === "blue" ) {
        redirect()
    }
});



