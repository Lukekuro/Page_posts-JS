export default class Search {
  constructor() {
    alert("Search js is successfully being executed")
  }
}

alert("Search js is successfully being executed")
