const express = require("express"),
mysql = require("mysql"),
sanitizeHTML = require("sanitize-html");
// bodyParser = require('body-parser');


let ourApp = express();
// const port = process.env.PORT || 3000;


ourApp.use(express.static('public'));

ourApp.use(express.urlencoded({ extended: false })); // turn off that why skyColor - will works

ourApp.use(express.json());

const pool  = mysql.createPool({
    connectionLimit : 10,
    host            : 'localhost',
    user            : 'root',
    password        : 'root',
    database        : 'example'
});


ourApp.listen(port, () => console.log(`Listening on port ${port}`));


function passwordProtected(req, res, next) {
    res.set('WWW-Authenticate', 'Basic realm=="Simple to do');
    console.log(req.headers.authorization);
    if ( req.headers.authorization == "Basic amE6dHk=" ) {
        next();
    } else {
        res.status(401).send("Error");
    }
}

ourApp.use(passwordProtected); // it is means to active for all sites

// Get all beers
// ourApp.get('/', passwordProtected, (req, res) => { // if will you use only one url then do and remove ourApp.use(passwordProtected)
ourApp.get('/', (req, res) => {
    pool.getConnection((err, connection) => {
        if(err) throw err
        // console.log('connected as id ' + connection.threadId)
        connection.query('SELECT * from items', (err, rows) => {
            
            connection.release() // return the connection to pool

            if (!err) {
                res.send(`
                <!DOCTYPE html>
                <html>
                <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Simple To-Do App</title>
                <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
                </head>
                <body>
                <div class="container">
                    <h1 class="display-4 text-center py-1">To-Do App!!!</h1>
                    
                    <div class="jumbotron p-3 shadow-sm">
                    <form id="create-form" method="POST">
                        <div class="d-flex align-items-center">
                        <input autofocus autocomplete="off" class="form-control mr-3" type="text" style="flex: 1;">
                        <button class="btn btn-primary">Add New Item</button>
                        </div>
                    </form>
                    </div>
                    
                    <ul id="item-list" class="list-group pb-5">
                  
                    </ul>
                    
                </div>
                <script>
                let items = ${JSON.stringify(rows)};
                </script>
                <script src="/browser.js"></script>
                <script src="https://unpkg.com/axios@1.1.2/dist/axios.min.js"></script>
                </body>
                </html>
                `)
            } else {
                console.log(err)
            }

            // if(err) throw err
            // console.log('The data from beer table are: \n', rows)
        })
    })
})

//Update item
ourApp.post('/update-item', function(req, res) {

    let safeText = sanitizeHTML(req.body.item_name, {allowedTags: [], allowedAttributes: {}});

    pool.getConnection((err, connection) => {
        if(err) throw err
        console.log(`connected as id ${connection.threadId}`)

        connection.query('UPDATE items SET item_name = ? WHERE item_id = ?', [safeText, req.body.item_id] , (err, rows) => {
            connection.release() // return the connection to pool

            if(!err) {
                res.json({item_name: safeText});

            } else {
                console.log(err)
            }

        })

        console.log(req.body)
    })
})

// Create item
ourApp.post('/create-item', (req, res) => {

    let safeText = sanitizeHTML(req.body.item_name, {allowedTags: [], allowedAttributes: {}});

    pool.getConnection((err, connection) => {
        if(err) throw err
        
        connection.query('INSERT INTO items SET item_name = ?', safeText, (err, rows) => {
            connection.release() // return the connection to pool
            if (!err) {
                res.json({item_id: rows.insertId , item_name: safeText});
            } else {
                console.log(err)
            }
            
            console.log('The data from beer table are:11 \n', rows)

        })
    })
});


// Delete item
ourApp.post('/delete-item', (req, res) => {

    pool.getConnection((err, connection) => {
        if(err) throw err
        connection.query('DELETE FROM items WHERE item_id = ?', req.body.item_id, (err, rows) => {
            connection.release() // return the connection to pool
            if (!err) {
                res.send(`Beer with the record ID ${req.params.item_id} has been removed.`)
            } else {
                console.log(err)
            }
            
            console.log('The data from beer table are: \n', rows)
        })
    })
});