// /**
//  * The main website (index)
//  */

// const express = require("express"),
// session = require("express-session"),
// router = require('./router'), // get router.js
// MongoStore = require('mongodb'),
// dotenv = require("dotenv"),
// flash = require("connect-flash"),
// app = express();

// dotenv.config();

// const options = {
//     connectionLimit: 10,
//     host            : process.env.DATABASE_HOST,
//     user            : process.env.DATABASE_USER,
//     password        : process.env.DATABASE_PASSWORD,
//     database        : process.env.DATABASE_NAME,
//     createDatabaseTable: true,
// };

// const sessionStore = new MySQLStore(options);

// let sessionOptions = session({ // you can see this in website -> Inspect -> Application -> Cookies (connect.sid)
//     secret: "js!",
//     store: sessionStore,
//     resave: false,
//     saveUninitialized: false,
//     cookie: {maxAge: 1000 * 60 * 60 * 24, httpOnly: true}
// });

// // sessionStore.onReady().then(() => { // test if MySQL store is works?
// // 	// MySQL session store ready for use.
// // 	console.log('MySQLStore ready');
// // }).catch(error => {
// // 	// Something went wrong.
// // 	console.error(error);
// // });


// app.use(sessionOptions);
// app.use(flash());

// app.use(express.urlencoded({ extended: false })); // turn off that why input->name: e.g. skyColor - will works
// app.use(express.json());

// app.use(express.static('public'));
// app.set('views', 'views') // the second field is name of folder/ get all file from folder as views
// app.set('view engine', 'ejs') // enable engine file as ejs 


// app.use('/', router); // get router to display website

// module.exports = app; // is possible import to another file (here you can see db.js)