/**
 * Database and create a localhost -- OLD
 */

// const mysql = require("mysql"),
// dotenv = require("dotenv");

// dotenv.config();

// const port = process.env.PORT,
// pool  = mysql.createPool({
//     connectionLimit : 10,
//     host            : process.env.DATABASE_HOST,
//     user            : process.env.DATABASE_USER,
//     password        : process.env.DATABASE_PASSWORD,
//     database        : process.env.DATABASE_NAME,
// });


// module.exports = pool;
// const app = require('./app');

// app.listen(port, () => console.log(`Listening on port ${port}`));


